truncate table spareparts

create table employee(empid varchar(30),empname varchar (30),empage int,address varchar (30),telephone varchar(20),
constraint ep primary key (empid))


create table customer(cid varchar(20),cname varchar(20),caddress varchar(20),ctelephone varchar(15),cemail varchar(30),
constraint cp primary key(cid))

create table job(jobid varchar(20),jname varchar(20),jobdate date,jobprice float,vehiclemodel varchar(20),cid varchar(20),empid varchar(20),spareid varchar(20),
constraint jp primary key(jobid))
alter table job
add constraint cf
foreign key (cid) references customer(cid) on delete cascade

alter table job
add constraint ef
foreign key (empid) references employee(empid)

alter table job
add constraint sf
foreign key (spareid) references spareparts(spareid)

alter table job 
drop constraint ef


truncate table customer
drop table job

select * from job
select * from customer
select * from employee
select * from spareparts
select * from customer
update employee
set empname='Kavindu'
where empid='12321'


Update job set cid='kavindu'
where jobid='ewrwer'
