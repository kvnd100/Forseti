/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SourceCode;

/**
 *
 * @author roy12
 */
abstract class Jobs {

    private String customerid;
    private String customername;
    private String address;
    private String telno;
    private String email;

    Jobs(String a, String b, String c, String d, String e) {
        this.customerid = a;
        this.customername = b;
        this.address = c;
        this.telno = d;
        this.email = e;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCustomerid() {
        return customerid;
    }

    public String getCustomername() {
        return customername;
    }

    public String getAddress() {
        return address;
    }

    public String getTelno() {
        return telno;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    
}

class Repairjob extends Jobs{
    
    String repairid;
    String date;

    public Repairjob(String repairid, String date, String a, String b, String c, String d, String e) {
        super(a, b, c, d, e);
        this.repairid = repairid;
        this.date = date;
    }

    public String getRepairid() {
        return repairid;
    }

    public void setRepairid(String repairid) {
        this.repairid = repairid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    
    
    
    
    
    
    
    
}


class Restorationjob extends Jobs
{
    
    private String restorationid;
    private String date;

    public Restorationjob(String restorationid, String date, String a, String b, String c, String d, String e) {
        super(a, b, c, d, e);
        this.restorationid = restorationid;
        this.date = date;
    }

    public String getRestorationid() {
        return restorationid;
    }

    public void setRestorationid(String restorationid) {
        this.restorationid = restorationid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

   
    
    
    
}


