/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SourceCode;

/**
 *
 * @author roy12
 */
public class Spareparts {
    
    private String partsid;
    private String supplierid;
    private String partsname;
    private int partsprice;
    private int partsquantity;

    public Spareparts(String partsid, String supplierid, String partsname, int partsprice, int partsquantity) {
        this.partsid = partsid;
        this.supplierid = supplierid;
        this.partsname = partsname;
        this.partsprice = partsprice;
        this.partsquantity = partsquantity;
    }

    public String getPartsid() {
        return partsid;
    }

    public void setPartsid(String partsid) {
        this.partsid = partsid;
    }

    public String getSupplierid() {
        return supplierid;
    }

    public void setSupplierid(String supplierid) {
        this.supplierid = supplierid;
    }

    public String getPartsname() {
        return partsname;
    }

    public void setPartsname(String partsname) {
        this.partsname = partsname;
    }

    public int getPartsprice() {
        return partsprice;
    }

    public void setPartsprice(int partsprice) {
        this.partsprice = partsprice;
    }

    public int getPartsquantity() {
        return partsquantity;
    }

    public void setPartsquantity(int partsquantity) {
        this.partsquantity = partsquantity;
    }
    
    
    
}
